# Google Voice Home Dialer — final source

This build implements the requested launcher behavior:

- Physical number keys are consumed by MainActivity and displayed in `number_entry`.
- The physical green key is Android `KEYCODE_CALL` (the TCL reports Linux `KEY_SEND`).
- Green calls `com.google.android.apps.googlevoice/.voice.home.androidintents.AndroidCallIntentActivity`
  with `ACTION_CALL`, so Google Voice should place the call directly.
- `CALL_PHONE` is declared in the manifest.

## Important device-level note

The TCL firmware may consume `KEY_SEND` globally before it reaches the HOME activity.
The source cannot override that global dispatch by itself.

The included `tools/check-keylayout.sh` is a read-only diagnostic for the rooted phone.
Run it in an ADB/WebADB shell if the stock Phone app still opens. It finds the keylayout
line responsible for `KEY_SEND`/`CALL` so the device-level mapping can be changed safely
rather than guessing at a keycode.
