#!/system/bin/sh
echo "=== KEY_SEND/CALL keylayout files ==="
for d in /system/usr/keylayout /vendor/usr/keylayout /product/usr/keylayout /odm/usr/keylayout; do
  if [ -d "$d" ]; then
    echo "--- $d ---"
    grep -HnE '(^|[[:space:]])(key[[:space:]]+[^[:space:]]+[[:space:]]+)?(CALL|SEND)([[:space:]]|$)' "$d"/*.kl 2>/dev/null
  fi
done
echo
echo "=== input devices ==="
getevent -lp 2>/dev/null | grep -A3 -B1 -E 'matrix-keypad|event5'
